# SIM-Sekolah
Sistem Informasi Management Nilai Siswa SMPN 14 Padang | Sumatera Barat
https://github.com/arimunandar/Sistem-Informasi-Nilai-Sekolah-SMP

Name : Ari Munandar
E-Mail : arimunandar.dev@gmail.com
Phone : +6282384669700