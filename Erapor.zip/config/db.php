<?php
mysql_connect("localhost:3306", "root", "") or die("Gagal Koneksi");
mysql_select_db("sims2") or die("Tidak ada Database");
?>